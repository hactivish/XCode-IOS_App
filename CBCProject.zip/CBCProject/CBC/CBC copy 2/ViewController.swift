//
//  ViewController.swift
//  CBC
//
//  Created by Melissa Lagoc on 2/3/17.
//  Copyright © 2017 Melissa Lagoc. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

   
   
   
    @IBOutlet weak var menubar_button: UIBarButtonItem!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
   
        
    
        
        
        
        
        
        
        if revealViewController() != (nil){
            menubar_button.target = self.revealViewController()
            menubar_button.action = "revealToggle:"
            
            
            self.view.addGestureRecognizer(revealViewController().panGestureRecognizer())
        }
        
        
        
        
    
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

