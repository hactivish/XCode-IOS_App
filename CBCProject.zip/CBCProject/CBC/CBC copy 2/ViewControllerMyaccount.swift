//
//  ViewControllerMyaccount.swift
//  CBC
//
//  Created by Melissa Lagoc on 2/4/17.
//  Copyright © 2017 Melissa Lagoc. All rights reserved.
//

import UIKit

class ViewControllerMyaccount: UIViewController {

    @IBOutlet weak var menubutton: UIBarButtonItem!
   
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        if revealViewController() != (nil){
            menubutton.target = self.revealViewController()
            menubutton.action = "revealToggle:"
            
            
            self.view.addGestureRecognizer(revealViewController().panGestureRecognizer())
        }

        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
