//
//  ViewController.swift
//  CBC
//
//  Created by Melissa Lagoc on 2/3/17.
//  Copyright © 2017 Melissa Lagoc. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIWebViewDelegate  {

   
   
 
    
    
    
    @IBOutlet weak var webViewHome: UIWebView!
   
   
    @IBOutlet weak var menubar_button: UIBarButtonItem!
    
    
    
  
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
   
       
        
        self.view.addSubview(webViewHome)
        
        webViewHome.delegate = self
        
        //1. Load web site into my web view
        let myURL = URL(string: "https://californiabeautyconcepts.com")
        let myURLRequest:URLRequest = URLRequest(url: myURL!)
        webViewHome.loadRequest(myURLRequest)
        
        if revealViewController() != (nil){
            menubar_button.target = self.revealViewController()
            menubar_button.action = "revealToggle:"
            
            
            self.view.addGestureRecognizer(revealViewController().panGestureRecognizer())
        }
        
  
        
       
        
        
        
        
        
        
   }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    func webViewDidStartLoad(_ webViewHome: UIWebView)
    {
        
    }
    func webViewDidFinishLoad(_ webViewHome: UIWebView)
    {
        
    }

}

